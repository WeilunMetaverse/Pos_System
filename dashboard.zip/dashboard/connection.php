<?php
$servername = "43.74.21.81";
$username = "root";
$password = "soemphp";
$dbname = "station_data";

// $servername = "localhost";
// $username = "root";
// $password = "";
// $dbname = "station_data";

// Create connection
$conn = mysqli_connect($servername, $username, $password, $dbname);


?>